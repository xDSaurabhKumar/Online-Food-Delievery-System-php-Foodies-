 
 <?php
 include ("config.php");
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
  
    <link rel="stylesheet" href="login.css">
   <title> User Login </title> 
</head>
  <body>
    <div class="wrapper">
      <div class="title">
Foodie Login</div>
<form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
        <div class="field">
          <input type="text" name="email" required>
          <label>Email Address</label>
        </div>
<div class="field">
          <input type="text" name="password" required>
          <label>Password</label>
        </div>
<div class="content">
          <div class="checkbox">
            <input type="checkbox" id="remember-me">
            <label for="remember-me">Remember me</label>
          </div>
<div class="pass-link">
<a href="#">Forgot password?</a></div>
</div>
<div class="field">
          <input type="submit" name = "login" value="Login">
        </div>
<div class="signup-link">
Not a member? <a href="Signup.php">Signup now</a></div>
</form>
</div>
</body>
</html>
<?php
if(isset($_POST['login'])){
$email =  $_POST['email'];
$password = $_POST['password'];
$sql = "SELECT * FROM Entries WHERE Email = '$email' && Password = '$password'";
$query = mysqli_query($conn,$sql);
$total = mysqli_num_rows($query);  

if($total == 1)

{
  session_start();
  header("Location:index.php");
}
else{
  echo "Login Error";
}
}
?>