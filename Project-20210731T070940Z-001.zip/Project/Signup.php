 
 <?php function function_alert($message) {   
 // Display the alert box    
    echo "<script type ='text/JavaScript'>";  
    echo "alert('$message')";  
    echo "</script>";   
}   
// Function call   
function_alert(" Welcome to Foodies  ");   

?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

</head>
<body>

  <form method ='post'  style="width:300px" >
  <div class="form-group" justify-content-center>
    <label for="fullname">Full Name:</label>
    <input type="name" class="form-control" name="fullname" id="fullname" aria-describedby="emailHelp" placeholder="Enter Your Name" required>
    
  </div>
  <div class="form-group">
    <label for="email">Email address</label>
    <input type="email" class="form-control" name="email" id="email" aria-describedby="emailHelp" placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    
    <label for="password">Password</label>
    <input type="password" name="password" class="form-control" id="password" placeholder="Password">
  </div>

  <div class="form-group">
    <label for="phone">Mobile No.</label>
    <input type="phone"  name="phone"class="form-control" id="phone" aria-describedby="emailHelp" placeholder="Enter mobile no">
  </div>
<button type="submit" class="btn btn-primary">Submit</button>
</form>    
</body>
</html>

<?php
error_reporting(1);
$fn=$_POST['fullname'];
$em=$_POST['email'];
$pass=$_POST['password'];
$ph=$_POST['phone'];
include "config.php";
$query="INSERT INTO Entries VALUES ('$fn','$em','$pass','$ph')";
$data=mysqli_query($conn,$query);
if($data)
{
  echo "<script>
  alert('Your details has successfully registered with Foodies');
  window.location.href='Loginform.php';
  </script>";
}
else{
  echo"Failed to insert";
}

?>