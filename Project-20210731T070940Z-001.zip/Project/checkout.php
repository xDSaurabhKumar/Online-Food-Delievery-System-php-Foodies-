<?php
 ini_set('display_errors', 0);
 ini_set('display_startup_errors', 1);
 error_reporting(E_ALL);

session_start();

if($_SERVER["REQUEST_METHOD"]=="POST")
{
    if(isset($_POST['addtocart']))
    {
      
    if(isset($_SESSION['cart']))  {
          
 $myitems=array_column($_SESSION['cart'],'name');                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         

 if(in_array($_POST['Name'] ,$myitems))
 {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
     echo "<script>alert('Item already added');
     window.location.href='shoppingcart.php';
     </script>";
     
 }
 else
{
$count=count($_SESSION['cart']);
$_SESSION['cart'][$count]= array('name'=>$_POST['Name'],'price'=>$_POST['Price'], 'Quantity'=>1);

echo "<script>alert ('Item Added');
    window.location.href='shoppingcart.php';
    </script>";   
 }
}

  else
   {
    $_SESSION['cart'][0] = array('name'=>$_POST['Name'],'price'=>$_POST['Price'],'Quantity'=>1);
    echo "<script>alert('Item Added');
    window.location.href='shoppingcart.php';
    </script>";   
 }

}

 if(isset($_POST['remove']))
{
    foreach($_SESSION['cart'] as $key => $value)
    {
       if($value['Name'] == $_POST['Name'])
       {
          
           unset($_SESSION['cart'][$key]);
           $_SESSION['cart']=array_values($_SESSION['cart']);
           echo "<script>
           alert('Item Removed');
           window.location.href='mycart.php';
           </script>";
       }
         
    }
    
  }

  if(isset($_POST['mod_quantity']))
  {
    foreach($_SESSION['cart'] as $key => $value)
    {
       if($value['Name'] == $_POST['Name'])
       {
           $_SESSION['cart'][$key]['Quantity']=$_POST['mod_quantity'];
        //  print_r($_SESSION['cart']);
         echo "<script>
         window.location.href='mycart.php';
         </script>";
       }

       else{
         echo "cant chnage the quantity";
       }
    }       
  }
}

?>




