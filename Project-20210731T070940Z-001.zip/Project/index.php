<?php
session_start();
include("config.php");

?>
<script>
 $(document).ready(function()
 {
     preloaderFadeOutTime = 500;
     function hidePreloader(){
         var preloader = $('center');
preloader.fadeOut(preloaderFadeOutTime);     }
 }
 hidePreloader();
 )   };
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Best Online Food Delievery Service in India | Foodies.com</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" media="screen and (max-width: 978px)" href="phone.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">  
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital@1&display=swap" rel="stylesheet">
</head>
<body>

    <nav id="navbar">
    
    <div id="logo">
        <img src="Images/100.jpeg" alt="Foodies.com">

        </div>
        
        <ul>
          <li class="item"><a href="">Home</a></li>
          <li class="item"><a href="">Services</a></li>
          <li class="item"><a href="AboutUs.html">About Us</a></li>
          <li class="item"><a href="">Contact Us</a></li>
         
        </ul>
        <div class="logout">
       <a href ="logout.php">LogOut</a>
       </div>
        </nav>
       
    <section id="home">
        <h1 class="h-primary">Welcome To Foodies</h1>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Distinctio quaerat laudantium nulla, praesentium exercitationem tenetur ab impedit aspernatur quam quasi non, cumque dolore iure magni aut reprehenderit? Rerum, temporibus repudiandae.</p>
      
<button class="btn">Order Now</button>
</section>

<services class="services-container">
    <h1 class="h-primary center">Our Services</h1>
    <div id="services">
        <div class="box">
            <img src="Images/img2.jpg" alt="Our Services">
             <h2 class="h-secondary center">Food Ordering</h2>
             <p class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non dolorem quaerat sit repellendus vitae, molestiae quam provident obcaecati reiciendis ut illum error, alias accusamus! Optio ab explicabo eaque adipisci cumque.</p>
              </div>

              <div class="box">
                <img src="Images/img2.jpg" alt="Our Services">
                 <h2 class="h-secondary center">Bulk Ordering</h2>`
                 <p class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non dolorem quaerat sit repellendus vitae, molestiae quam provident obcaecati reiciendis ut illum error, alias accusamus! Optio ab explicabo eaque adipisci cumque.</p>
                 
            
        </div>

        <div class="box">
            <img src="Images/img2.jpg" alt="Food Catering">
             <h2 class="h-secondary center">Food Catering</h2>
             <p class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Non dolorem quaerat sit repellendus vitae, molestiae quam provident obcaecati reiciendis ut illum error, alias accusamus! Optio ab explicabo eaque adipisci cumque.</p>
             </div>
</div>
</services>


<section id="our-clients">
    <h1 class="h-primary center">Our Clients</h1>
    <div id="clients">
        <div class="client-item">
            <img src="Images/swiggy.jpg" alt="Our Clients">
        </div>
        <div class="client-item">
        <img src="Images/Zomato.png" alt="Our Clients">
        </div>

        <div class="client-item">
            <img src="Images/clients1.png" alt="Our Clients">
        </div>
        
        <div class="client-item">
            <img src="Images/appl.png" alt="Our Clients">
        </div>

    </div>
</section>


<section id="contact">
<h1 class="h-primary center">Contact Us</h1>
<div id="contact-box">

<form action="">
    <div class="form-group">
        <label for="name">Name: </label>
        <input type="text" name="name" id="name" placeholder="Enter You Name">
    </div>

    <div class="form-group">
        <label for="phone">Phone: </label>
        <input type="phone" name="name" id="name" placeholder="Enter Your Contact No. ">
    </div>

    <div class="form-group">
        <label for="email">Email: </label>
        <input type="email" name="email" id="name" placeholder="Enter You Valid Mail Id">
    </div>

    <div class="form-group">
        <label for="name">Message </label>
        <textarea name="message" id="message" cols="25" rows="10"></textarea>
    </div>


</form>

</section>

<footer>

<div class="center">
    Copyright &copy; www.foodies.com. All rights reserved
</div>

</footer>


</body>
</html>