<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','Orders');
//Trying to connect to database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
//chck cnction
if($conn == false){
    die('Error : Cannot connect');
}
else{
  echo  "connection_status:connected" ;
}


if($_SERVER["REQUEST_METHOD"]=="POST")
{
if(isset($_POST['purchase']))
 {
    $query1="INSERT INTO `Order_Manager`(`Full_Name`,`Mobile_No`,`Address`,`Pay_Mode`) VALUES ('$_POST[fullname]','$_POST[phone_no]','$_POST[address]','$_POST[pay_mode]')";
    if(mysqli_query($conn,$query1))
    { 
        $Order_Id=mysqli_insert_id($conn);
        $query2= "INSERT INTO `user_orders`(`Order_Id`, `Name`, `Price`, `Quantity`) VALUES (?,?,?,?)";
        $stmt=mysqli_prepare($conn,$query2);
        if($stmt)
        {
         mysqli_stmt_bind_param($stmt,"isii",$Order_Id,$Name,$Price,$Quantity);
         foreach($_SESSION['cart'] as $key => $values)
{
           $Name=$values['name'];
           $Price=$values['price'];
           $Quantity=$values['Quantity'];
           mysqli_stmt_execute($stmt);
           
}
     unset($_SESSION['cart']);
     echo"<script>
     alert('You,re Done With The Order, Thank You...');
     window.location.href='shoppingcart.php';
    </script>";

        }
        else{
            echo"<script>
            alert('SQL Query Prepare Error');
            window.location.href='mycart.php';
            </script>";
        }

    }

    // {
    //     echo"<script>
    //     alert('You,re Done With The Order, Thank You...');
    //     window.location.href='mycart.php';
    //     </script>";
    // }

    else{
        echo"<script>
        alert('SQL Error');
        window.location.href='mycart.php';
        </script>";
    }

 }
}
?>