<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="shoppingcart.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
</head>
<body> 

<div>
<ul class="nav nav-tabs" id="myTab" role="tablist">
  <li class="nav-item" role="presentation">
    <a class="nav-link " id="home-tab" data-toggle="tab" href="index.php">Home</a>
  </li>
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#" role="tab" aria-controls="profile" aria-selected="false">Services</a>
  </li>
  <li class="nav-item" role="presentation">
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="contact-tab" data-toggle="tab" href="AboutUs.html" role="tab" aria-controls="contact" aria-selected="false">AboutUs</a>
  </li>

  <li class="nav-item" role="presentation">
    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Contact Us </a>
  </li>
  
  <li class="nav-item" role="presentation">
    <a class="nav-link" id="contact-tab" data-toggle="tab" href="mycart.php" role="tab" aria-controls="contact"> Cart <i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
  </li>
</ul>
</div>

<?php 
$count=0;
if(isset($_SESSION['cart']))
{
  $count=count($_SESSION['cart']);
}

?>

<a href="mycart.php" class="btn btn-outline-success pull-right"> My Cart (<?php echo $count;?>)</a>
<div class = "container" >
<h2>ONLINE SHOPPING CART</h2>
<div class="row">
<?php
include "config.php"; 
 $query= "SELECT `name`, `image`, `price`, `discount` FROM `Shoppingcart` order by id ASC";
 $queryfire = mysqli_query($conn, $query);
$num = mysqli_num_rows($queryfire);
if($num > 0){
  while($product = mysqli_fetch_array($queryfire)){
   
  ?>
  
<div class= "col-lg-3 col-md-3 col-sm-12">
<form action = "checkout.php" method="POST">
    <div class="card mt-2">
      <h6 class="card-title bg-info text-white p-2 text-uppercase"><?php echo $product['name'];   ?></h6>
     <div class="card-body">
     <img src="<?php echo $product['image']; ?>" alt="phone" class="img-fluid mb-2">
     <h6> &#8377; <?php echo $product['price'];?>
     <span>(<?php echo $product['discount']; ?>% Off) </span>
     </h6>
     <h6 class="badge badge-success">4.4 <i class="fa fa-star"></i> </h6>
     
     <input type="hidden" name="Name" class="form-control" placeholder="Name" value="<?php echo $product['name'];   ?>">
     <input type="hidden" name="Price" class="form-control" placeholder="Price" value="<?php echo $product['price'];   ?>">
     <input type="hidden" name="Image" class="form-control" placeholder="Image" value="<?php echo $product['image'];   ?>">
     <input type="hidden" name="Discount" class="form-control" placeholder="Discount" value="<?php echo $product['discount'];   ?>">
     </div>
    <div> <div class="btn-group d-flex flex-fill"><button class="btn btn-success" name="addtocart">Add To Cart </button>
    </div>
    </div>
</div>
  </form>
</div>
<?php
  }
} 
?>
</div>
</div>
</body>
</html>